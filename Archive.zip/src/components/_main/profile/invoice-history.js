'use client';

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'next/navigation';
import { Box, Typography } from '@mui/material';

import * as api from 'src/services';
import Table from 'src/components/table/table';
import OrderRow from '@/components/table/rows/order-row';
import OrderCard from 'src/components/cards/order';

export default function InvoiceHistory({ compact = false }) {
  const searchParams = useSearchParams();
  const pageParam = compact ? '1' : searchParams.get('page') || '1';

  const { data, isPending: isLoading, isError } = useQuery({
    queryKey: ['user-invoice', pageParam],
    queryFn: () => api.getUserInvoice(`?page=${pageParam}`),
    retry: false
  });

  const tableData = {
    data: isLoading ? null : data?.data,
    count: data?.data?.count
  };

  const TABLE_HEAD = [
    { id: 'name', label: 'Product' },
    { id: 'items', label: 'Items' },
    { id: 'total', label: 'Total' },
    { id: 'inventoryType', label: 'Status' },
    { id: 'createdAt', label: 'Date' },
    { id: 'action', label: 'Action' }
  ];

  if (isError) {
    return (
      <Box sx={{ py: 3 }}>
        <Typography color="error">
          Unable to load your orders. Please try again.
        </Typography>
      </Box>
    );
  }

  return (
    <Box mt={compact ? 0 : 3} sx={{ minWidth: 0 }}>
      {isLoading ? (
        <Typography sx={{ py: 3, textAlign: 'center' }}>
          Loading orders...
        </Typography>
      ) : (
        <Table
          headData={TABLE_HEAD}
          data={tableData}
          isLoading={false}
          row={OrderRow}
          mobileRow={OrderCard}
          compact={compact}
        />
      )}
    </Box>
  );
}